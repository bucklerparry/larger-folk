if you're not familiar with how to install caves of qud mods,
go to your user folder on your computer, then navigate to
AppData>LocalLow>Freehold Games>CavesOfQud>Mods, 
and drop the larger_folk folder this txt is inside of into it.
Dynamic weight gain is disabled by default since it has some untested ramifications i'm not sure
are playthrough-safe rn, but can be enabled in the options menu, scroll down to the bottom of the
options list for this mod's options.